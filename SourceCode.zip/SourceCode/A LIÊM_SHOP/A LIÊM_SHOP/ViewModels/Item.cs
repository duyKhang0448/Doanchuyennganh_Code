﻿using A_LIÊM_SHOP.Models;

namespace A_LIÊM_SHOP.ViewModels
{
    public class Item
    {
        public Product Product { get; set; }

        public int Quantity { get; set; }
    }
}
